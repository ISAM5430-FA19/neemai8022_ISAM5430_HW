﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            for (char i = 'A'; i <= 'H'; i++)
            {
                for (char j = 'A'; j <= 'H'; j++)
                {
                    if (i != j)
                    {
                        if (((i == 'A' || i == 'E') && (j != 'A' || j != 'E')) || ((j == 'A' || j == 'E') && (i != 'A' || i != 'E')))


                        {
                            Console.Write($"{i}{j},");
                            for (char z = 'A'; z <= 'H'; z++)
                            {
                                if (j != z && i != z)
                                {
                                    {
                                        Console.Write($"{i}{j}{z},");
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Console.WriteLine();
        }    
    }
}
