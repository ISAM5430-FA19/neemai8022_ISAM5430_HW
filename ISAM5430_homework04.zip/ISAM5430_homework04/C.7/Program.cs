﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._7
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "";
            Console.WriteLine("Enter a String: ");
            s = Console.ReadLine();

            int vcount = 0;
            int ccount = 0;
            for (int c = 0; c < s.Length; c++)
            {
                if (s[c] == 'A' || s[c] =='E' || s[c] == 'I' || s[c] == 'O' || s[c] == 'U' || s[c] == 'Y') 

                {
                    vcount = vcount + 1;
                }
                else
                {
                    ccount = ccount + 1;
                }
            }
            Console.WriteLine($"Count of VOWELS : {vcount}");
            Console.WriteLine($"Count of CONSONANTS : {ccount}");



        }
    }
}
