﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._6
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "";
            Console.WriteLine("Enter a String: ");
            s = Console.ReadLine();
            
            int count = 0;
            foreach(char c in s)
            {
                count = count + 1;
            }
            Console.WriteLine($"Count of Characters in string : {count}");
        }
    }
}
