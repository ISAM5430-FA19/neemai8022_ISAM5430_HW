﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B._1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            {
                for (int i = 1; i <= 5; i++)
                {
                    for (int j = i+1; j <= 5; j++)
                    {
                        sum = (i * j) + sum;
                        Console.WriteLine($"{i}{j}");

                    }

                }
                Console.WriteLine(sum);
            }
        }
    }
}
