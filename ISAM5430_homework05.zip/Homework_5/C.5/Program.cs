﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._5
{
    class Program
    {
        static void Main(string[] args)
        {
            Date date = new Date(12, 21, year: 1995);
            date.DisplayDate();
        }
    }
}
