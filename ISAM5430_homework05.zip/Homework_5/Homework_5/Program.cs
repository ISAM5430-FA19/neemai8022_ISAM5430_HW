﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_5
{
    class Program
    {
        static void Main(string[] args)
        {

            Student s1 = new Student(1648951,"Ishan","Neema");
            s1.Gpa = 3.4;
            s1.Major = "MIS";
            s1.Classification = "International";
            Console.WriteLine($"Name :{s1.FName} {s1.LName}");
            Console.WriteLine($"Overall GPA :{s1.Gpa}");
                       
        }
    }
}
