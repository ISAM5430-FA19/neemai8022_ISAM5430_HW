﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_5
{
    class Student
    {

        public Student(int StudentNumber, string FName, string LName)
        {
            _stdentNumber = StudentNumber;
            _fname = FName;
            _lname = LName;
        }
        public Student(double Gpa, string Major, string Classification)
        {
            _gpa = Gpa;
            _major = Major;
            _classification = Classification;
        }
        private int _stdentNumber;
        private string _fname;
        private string _lname;
        private double _gpa;
        private string _classification;
        private string _major;

        public int StdentNumber
        {
            get
            {
                return _stdentNumber;
            }
            set
            {
               
                _stdentNumber = value;
            }
        }

        public string FName
        {
            get
            {
                return _fname;
            }
            set
            {
                _fname = value; ;
            }
        }

        public string LName
        {
            get
            {
                return _lname;
            }
            set
            {
                 _lname=value;
            } 
        }

        public double Gpa
        {
            get
            {
                return _gpa;
            }
            set
            {
                _gpa = value;
            }
        }
        public string Major
        {
            get
            {
                return _major;
            }
            set
            {
                _major = value;
            }
        }
        public string Classification
        {
            get
            {
                return _classification;
            }
            set
            {
                _classification = value;
            }
        }
        
            

        
    }
}
