﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Motorway subMotorway = new Motorway("I45", 4, true);
            Motorway motorway = new Motorway("Jones Road", "Road", "W", "concrete", 2, false, "Jersey Village");
            subMotorway.GetMotorName();
            subMotorway.GetMotorNameAndLanes();
            subMotorway.GetMotorNameAndToll();
            Console.WriteLine(motorway);
        }
    }
}
