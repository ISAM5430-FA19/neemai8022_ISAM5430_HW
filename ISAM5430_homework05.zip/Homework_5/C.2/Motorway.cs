﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._2
{
    class Motorway
    {
        private string v1;
        private int v2;
        private bool v3;

        public Motorway(string motorName, string type, string direction, string surface, int lanes, bool toll, string maintenanceParty)
        {
            NameOfMotor = motorName;
            Type = type;
            Direction = direction;
            Surface = surface;
            Lanes = lanes;
            Toll = toll;
            MaintenanceParty = maintenanceParty;
        }

        public Motorway(string v1, int v2, bool v3)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
        }

        public string NameOfMotor { get; set; }
        public string Type { get; set; }
        public string Direction { get; set; }
        public string Surface { get; set; }
        public int Lanes { get; set; }
        public bool Toll { get; set; }
        public string MaintenanceParty { get; set; }
        public void GetMotorName() => Console.WriteLine($"Full name of the motor : {NameOfMotor}");
        public void GetMotorNameAndToll() => Console.WriteLine($"Full name of the motor : {NameOfMotor} \n" + $" Toll : {Toll}");
        public void GetMotorNameAndLanes() => Console.WriteLine($"Full name of the motor : {NameOfMotor} \n" + $" Lanes : {Lanes}");
        public override string ToString()
        {
            return ($"Full name of the motor : {NameOfMotor} \n" + $"Type : {Type} \n" + $"Direction : {Direction} \n" + $"Surface : {Surface} \n" + $"Lanes : {Lanes} \n" +
                $"Toll : {Toll} \n" + $"MaintenanceParty : {MaintenanceParty} \n");
        }
    }
}
