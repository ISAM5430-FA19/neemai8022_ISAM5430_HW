﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C._3
{
    class Program
    {
        static void Main(string[] args)
        {
            Money m = new Money(1.5, 25);
            Money m1 = new Money(1.5);
            m.DecrementMoney();
            m1.IncrementMoney();
            Console.WriteLine(m.GetMoneyValue());
            Console.WriteLine(m1.GetMoneyValue());
            Console.WriteLine(m);
            Console.WriteLine(m1);
        }
    }
}
